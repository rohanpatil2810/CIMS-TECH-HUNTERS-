package com.CIMS.demo.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.CIMS.demo.entity.Parent;
import com.CIMS.demo.exception.EmailUpdateFailedException;
import com.CIMS.demo.exception.InvalidCredentialsException;
import com.CIMS.demo.exception.ResourceNotFoundException;
import com.CIMS.demo.repo.ParentRepo;
import com.CIMS.demo.service.DashboardService;
import com.CIMS.demo.service.EmailService;
import com.CIMS.demo.service.ParentService;

public class ParentServiceTest {

    @InjectMocks
    private ParentService parentService;

    @Mock
    private ParentRepo parentRepo;

    @Mock
    private DashboardService dashboardService;

    @Mock
    private EmailService emailService;

    private Parent testParent;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        testParent = new Parent();
        testParent.setParentName("John");
        testParent.setParentEmailId("john@example.com");
        testParent.setParentPw("password123");
        testParent.setContactNumber("1234567890");
    }

    @Test
    public void testRegisterParentHere_Success() {
        when(parentRepo.existsByParentEmailId(testParent.getParentEmailId())).thenReturn(false);
        when(parentRepo.existsByContactNumber(testParent.getContactNumber())).thenReturn(false);
        when(parentRepo.save(any(Parent.class))).thenReturn(testParent);

        ResponseEntity<String> response = parentService.registerParentHere(testParent);
        assertEquals("Parent registration successful.", response.getBody());

        verify(parentRepo).save(testParent);
    }

    @Test
    public void testRegisterParentHere_DuplicateEmail() {
        when(parentRepo.existsByParentEmailId(testParent.getParentEmailId())).thenReturn(true);

        assertThrows(EmailUpdateFailedException.class, () -> {
            parentService.registerParentHere(testParent);
        });
    }

    @Test
    public void testRegisterParentHere_DuplicateContact() {
        when(parentRepo.existsByParentEmailId(testParent.getParentEmailId())).thenReturn(false);
        when(parentRepo.existsByContactNumber(testParent.getContactNumber())).thenReturn(true);

        assertThrows(EmailUpdateFailedException.class, () -> {
            parentService.registerParentHere(testParent);
        });
    }

    @Test
    public void testLoginAndReturnDashboard_Success() {
        when(parentRepo.findByParentEmailId(testParent.getParentEmailId())).thenReturn(testParent);
        when(dashboardService.parentDashboard(testParent.getParentEmailId())).thenReturn(new HashMap<>());

        ResponseEntity<Map<String, Object>> response = parentService.loginAndReturnDashboard(testParent);
        assertEquals("Login Successful", response.getBody().get("message"));
    }

    @Test
    public void testLoginAndReturnDashboard_InvalidCredentials() {
        when(parentRepo.findByParentEmailId(testParent.getParentEmailId())).thenReturn(null);

        assertThrows(InvalidCredentialsException.class, () -> {
            parentService.loginAndReturnDashboard(testParent);
        });
    }

    @Test
    public void testChangePassword_Success() {
        when(parentRepo.findByParentEmailId(testParent.getParentEmailId())).thenReturn(testParent);

        ResponseEntity<String> response = parentService.changePassword(testParent.getParentEmailId(), "newpass");
        assertEquals("Password changed successfully.", response.getBody());

        verify(parentRepo).updateParentPw(testParent.getParentEmailId(), "newpass");
    }

    @Test
    public void testChangePassword_Failure() {
        when(parentRepo.findByParentEmailId(testParent.getParentEmailId())).thenReturn(null);

        assertThrows(ResourceNotFoundException.class, () -> {
            parentService.changePassword(testParent.getParentEmailId(), "newpass");
        });
    }

    @Test
    public void testUpdateParentEmail_Success() {
        when(parentRepo.findByParentEmailId("old@example.com")).thenReturn(testParent);
        when(parentRepo.existsByParentEmailId("new@example.com")).thenReturn(false);

        ResponseEntity<String> response = parentService.updateParentEmail("old@example.com", "new@example.com");
        assertEquals("Email updated to: new@example.com", response.getBody());

        verify(parentRepo).save(testParent);
    }

    @Test
    public void testUpdateParentEmail_AlreadyExists() {
        when(parentRepo.findByParentEmailId("old@example.com")).thenReturn(testParent);
        when(parentRepo.existsByParentEmailId("new@example.com")).thenReturn(true);

        assertThrows(EmailUpdateFailedException.class, () -> {
            parentService.updateParentEmail("old@example.com", "new@example.com");
        });
    }

    @Test
    public void testUpdateParentEmail_Failure() {
        when(parentRepo.findByParentEmailId("old@example.com")).thenReturn(null);

        assertThrows(EmailUpdateFailedException.class, () -> {
            parentService.updateParentEmail("old@example.com", "new@example.com");
        });
    }

    @Test
    public void testGetAllParentData() {
        List<Parent> parentList = Arrays.asList(testParent);
        when(parentRepo.findAll()).thenReturn(parentList);

        List<Parent> result = parentService.getAllParentData();
        assertEquals(1, result.size());
        assertEquals("John", result.get(0).getParentName());
    }
}
