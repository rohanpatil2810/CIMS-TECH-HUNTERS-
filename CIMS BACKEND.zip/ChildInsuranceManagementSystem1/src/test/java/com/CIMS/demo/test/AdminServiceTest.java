package com.CIMS.demo.test;

import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.CIMS.demo.entity.Admin;
import com.CIMS.demo.exception.InvalidCredentialsException;
import com.CIMS.demo.service.AdminService;

class AdminServiceTest {
    
    private AdminService adminService;
    private Admin testAdmin;
    
    @BeforeEach
    void setUp() {
        adminService = new AdminService();
        testAdmin = new Admin();
        // Set values directly if fields are public
        testAdmin.adminEmail = "admin@cims.com";
        testAdmin.adminPassword = "secure123";
        
        // OR if you have different field names but can't change them:
        // testAdmin.email = "admin@cims.com";
        // testAdmin.password = "secure123";
    }
    
   
    @Test
    void adminLoginHere_WrongPassword() {
        testAdmin.adminPassword = "wrongpass";
        assertThrows(InvalidCredentialsException.class, () -> {
            adminService.adminLoginHere(testAdmin);
        });
    }
    
    @Test
    void adminLoginHere_WrongEmail() {
        testAdmin.adminEmail = "wrong@email.com";
        assertThrows(InvalidCredentialsException.class, () -> {
            adminService.adminLoginHere(testAdmin);
        });
    }
    
    @Test
    void adminLoginHere_NullAdmin() {
        assertThrows(NullPointerException.class, () -> {
            adminService.adminLoginHere(null);
        });
    }
}