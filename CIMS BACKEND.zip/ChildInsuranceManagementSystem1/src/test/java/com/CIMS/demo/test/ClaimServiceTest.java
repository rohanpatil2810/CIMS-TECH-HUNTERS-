package com.CIMS.demo.test;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.CIMS.demo.entity.Claim;
import com.CIMS.demo.entity.Parent;
import com.CIMS.demo.entity.Policy;

class ClaimEntityTest {

    private Claim claim;
    private Parent parent;
    private Policy policy;

    @BeforeEach
    void setUp() {
        // Initialize parent
        parent = new Parent();
        parent.setParent_Id(1);
        
        // Initialize policy
//        policy = new Policy();
//        policy.setPolicy_Id(1);
        
        // Initialize claim using no-args constructor
        claim = new Claim();
        claim.setClaimId(1);
        claim.setReason("Medical expenses");
        claim.setDate(LocalDate.of(2023, 5, 15));
        claim.setStatus("Pending");
        claim.setParent(parent);
        claim.setPolicy(policy);
    }

    @Test
    void testNoArgsConstructor() {
        Claim emptyClaim = new Claim();
        assertNotNull(emptyClaim);
        assertEquals(0, emptyClaim.getClaimId());
        assertNull(emptyClaim.getReason());
        assertNull(emptyClaim.getDate());
        assertNull(emptyClaim.getStatus());
        assertNull(emptyClaim.getParent());
        assertNull(emptyClaim.getPolicy());
    }

    @Test
    void testAllArgsConstructor() {
        Claim fullClaim = new Claim(2, "Accident claim", 
                                  LocalDate.of(2023, 6, 20), 
                                  "Approved", parent, policy);
        
        assertNotNull(fullClaim);
        assertEquals(2, fullClaim.getClaimId());
        assertEquals("Accident claim", fullClaim.getReason());
        assertEquals(LocalDate.of(2023, 6, 20), fullClaim.getDate());
        assertEquals("Approved", fullClaim.getStatus());
        assertSame(parent, fullClaim.getParent());
        assertSame(policy, fullClaim.getPolicy());
    }

    @Test
    void testGettersAndSetters() {
        // Test getters with values set in setUp()
        assertEquals(1, claim.getClaimId());
        assertEquals("Medical expenses", claim.getReason());
        assertEquals(LocalDate.of(2023, 5, 15), claim.getDate());
        assertEquals("Pending", claim.getStatus());
        assertSame(parent, claim.getParent());
        assertSame(policy, claim.getPolicy());
        
        // Test setters with new values
        claim.setClaimId(10);
        claim.setReason("Updated reason");
        claim.setDate(LocalDate.of(2023, 7, 1));
        claim.setStatus("Rejected");
        
        Parent newParent = new Parent();
        Policy newPolicy = new Policy();
        claim.setParent(newParent);
        claim.setPolicy(newPolicy);
        
        assertEquals(10, claim.getClaimId());
        assertEquals("Updated reason", claim.getReason());
        assertEquals(LocalDate.of(2023, 7, 1), claim.getDate());
        assertEquals("Rejected", claim.getStatus());
        assertSame(newParent, claim.getParent());
        assertSame(newPolicy, claim.getPolicy());
    }

        
}