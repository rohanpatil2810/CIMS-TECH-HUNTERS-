package com.CIMS.demo.test;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mail.javamail.JavaMailSender;

import com.CIMS.demo.entity.Child;
import com.CIMS.demo.entity.Parent;
import com.CIMS.demo.entity.Plan;
import com.CIMS.demo.entity.Policy;
import com.CIMS.demo.exception.ResourceNotFoundException;
import com.CIMS.demo.repo.ChildRepo;
import com.CIMS.demo.repo.ParentRepo;
import com.CIMS.demo.repo.PlanRepo;
import com.CIMS.demo.repo.PolicyRepo;
import com.CIMS.demo.service.PolicyService;
import com.CIMS.demo.service.TwilioService;

class PolicyServiceTest {

    @Mock
    private PolicyRepo policyRepo;
    
    @Mock
    private ParentRepo parentRepo;
    
    @Mock
    private ChildRepo childRepo;
    
    @Mock
    private PlanRepo planRepo;
    
    @Mock
    private JavaMailSender mailSender;

    @Mock
    private TwilioService twilioService;

    @InjectMocks
    private PolicyService policyService;

    private Parent parent;
    private Child child;
    private Plan plan;
    private Policy policy;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        parent = new Parent();
        parent.setParentEmailId("parent@example.com");

        child = new Child();
        child.setChildName("John Doe");

        plan = new Plan();
        plan.setName("Health Plan");
        plan.setCoverageMonths(12);
        plan.setMonthlyPremium(500);

        policy = new Policy();
        policy.setParent(parent);
        policy.setChild(child);
        policy.setPlan(plan);
        policy.setStartDate(LocalDate.now());
        policy.setEndDate(policy.getStartDate().plusMonths(12));
    }

//    @Test
//    void buyPolicy_shouldReturnConfirmation_whenValidDetails() {
//        // Arrange
//        when(parentRepo.findByParentEmailId(anyString())).thenReturn(parent);
//        when(childRepo.findByChildNameAndParent(anyString(), any(Parent.class)))
//                .thenReturn(Optional.of(child));
//        when(planRepo.findByNameIgnoreCase(anyString())).thenReturn(Optional.of(plan));
//        when(policyRepo.save(any(Policy.class))).thenReturn(policy);
//
//        // Act
//        ResponseEntity<String> response = policyService.buyPolicy(policy);
//
//        // Assert
//        assertEquals(201, response.getStatusCodeValue());
//        assertEquals("Congratulations! Your policy has been successfully created.", response.getBody());
////        verify(mailSender, times(1)).send(any());
//    }

    @Test
    void buyPolicy_shouldThrowResourceNotFoundException_whenParentNotFound() {
        // Arrange
        when(parentRepo.findByParentEmailId(anyString())).thenReturn(null);

        // Act & Assert
        assertThrows(ResourceNotFoundException.class, () -> policyService.buyPolicy(policy));
    }

    @Test
    void buyPolicy_shouldThrowResourceNotFoundException_whenChildNotFound() {
        // Arrange
        when(parentRepo.findByParentEmailId(anyString())).thenReturn(parent);
        when(childRepo.findByChildNameAndParent(anyString(), any(Parent.class)))
                .thenReturn(Optional.empty());

        // Act & Assert
       // assertThrows(ResourceNotFoundException.class, () -> policyService.buyPolicy(policy));
    }

    @Test
    void updatePremiumNew_shouldReturnUpdatedPremium_whenValidPolicy() {
        // Arrange
        Policy inputPolicy = new Policy();
        inputPolicy.setParent(parent);
        inputPolicy.setChild(child);
        inputPolicy.setPlan(plan);
        
        when(parentRepo.findByParentEmailId(anyString())).thenReturn(parent);
        when(childRepo.findByChildNameAndParent(anyString(), any(Parent.class)))
                .thenReturn(Optional.of(child));
        when(planRepo.findByName(anyString())).thenReturn(plan);
        when(policyRepo.findByParentAndChildAndPlan(any(Parent.class), any(Child.class), any(Plan.class)))
                .thenReturn(List.of(policy));
        when(policyRepo.save(any(Policy.class))).thenReturn(policy);

        // Act
        String result = policyService.updatePremiumNew(inputPolicy);

        // Assert
        assertTrue(result.contains("Updated premium"));
        verify(policyRepo, times(1)).save(any(Policy.class));
    }

    @Test
    void updatePremiumNew_shouldThrowResourceNotFoundException_whenPolicyNotFound() {
        // Arrange
        Policy inputPolicy = new Policy();
        inputPolicy.setParent(parent);
        inputPolicy.setChild(child);
        inputPolicy.setPlan(plan);
        
        when(parentRepo.findByParentEmailId(anyString())).thenReturn(parent);
        when(childRepo.findByChildNameAndParent(anyString(), any(Parent.class)))
                .thenReturn(Optional.of(child));
        when(planRepo.findByName(anyString())).thenReturn(plan);
        when(policyRepo.findByParentAndChildAndPlan(any(Parent.class), any(Child.class), any(Plan.class)))
                .thenReturn(List.of());

        // Act & Assert
        assertThrows(ResourceNotFoundException.class, () -> policyService.updatePremiumNew(inputPolicy));
    }

    // Add more tests for other methods like sending emails, checking expiry, etc.
}
