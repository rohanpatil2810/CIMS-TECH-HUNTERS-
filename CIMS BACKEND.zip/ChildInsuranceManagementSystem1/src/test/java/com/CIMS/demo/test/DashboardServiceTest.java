package com.CIMS.demo.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.CIMS.demo.entity.Child;
import com.CIMS.demo.entity.Claim;
import com.CIMS.demo.entity.Parent;
import com.CIMS.demo.entity.Plan;
import com.CIMS.demo.entity.Policy;
import com.CIMS.demo.entity.Transaction;
import com.CIMS.demo.exception.ResourceNotFoundException;
import com.CIMS.demo.repo.ChildRepo;
import com.CIMS.demo.repo.ClaimRepo;
import com.CIMS.demo.repo.ParentRepo;
import com.CIMS.demo.repo.PolicyRepo;
import com.CIMS.demo.service.DashboardService;

@ExtendWith(MockitoExtension.class)
public class DashboardServiceTest {

    @Mock
    private ParentRepo parentRepo;

    @Mock
    private ChildRepo childRepo;

    @Mock
    private PolicyRepo policyRepo;

    @Mock
    private ClaimRepo claimRepo;

    @InjectMocks
    private DashboardService dashboardService;

    private Parent parent;
    private Child child;
    private Policy policy;
    private Plan plan;
    private Claim claim;
    private Transaction transaction;

    @BeforeEach
    public void setUp() {
        // Set up plan
        plan = new Plan();
        plan.setName("Education Plan");

        // Set up policy
        policy = new Policy();
        policy.setPlan(plan);

        // Set up child
        child = new Child();
        child.setChildName("Alice");
        child.setPolicies(Arrays.asList(policy));

        // Set up claim
        claim = new Claim();

        // Set up parent
        parent = new Parent();
        parent.setParentName("John Doe");
        parent.setParentEmailId("john@example.com");
        parent.setChildren(Arrays.asList(child));
        parent.setClaims(Arrays.asList(claim));
        parent.setTransactions(Arrays.asList(transaction));
    }

    @Test
    public void testParentDashboard_Success() {
        // Mock repository calls
        when(parentRepo.findByParentEmailId("john@example.com")).thenReturn(parent);

        // Call service method
        Map<String, Object> dashboardData = dashboardService.parentDashboard("john@example.com");

        // Verify results
        assertNotNull(dashboardData);
        assertEquals("John Doe", dashboardData.get("parentName"));
        assertEquals("john@example.com", dashboardData.get("email"));

        @SuppressWarnings("unchecked")
        List<String> childrenNames = (List<String>) dashboardData.get("childrenNames");
        assertEquals(1, childrenNames.size());
        assertEquals("Alice", childrenNames.get(0));

        @SuppressWarnings("unchecked")
        List<String> plans = (List<String>) dashboardData.get("Plan");
        assertEquals(1, plans.size());
        assertEquals("Education Plan", plans.get(0));

        assertEquals(1L, dashboardData.get("claimCount"));
        assertEquals(1L, dashboardData.get("transactionCount"));
    }

    @Test
    public void testParentDashboard_EmptyChildren() {
        parent.setChildren(Collections.emptyList());
        when(parentRepo.findByParentEmailId("john@example.com")).thenReturn(parent);

        Map<String, Object> dashboardData = dashboardService.parentDashboard("john@example.com");

        @SuppressWarnings("unchecked")
        List<String> childrenNames = (List<String>) dashboardData.get("childrenNames");
        assertTrue(childrenNames.isEmpty());

        @SuppressWarnings("unchecked")
        List<String> plans = (List<String>) dashboardData.get("Plan");
        assertTrue(plans.isEmpty());
    }

    @Test
    public void testParentDashboard_NullClaimsAndTransactions() {
        parent.setClaims(null);
        parent.setTransactions(null);
        when(parentRepo.findByParentEmailId("john@example.com")).thenReturn(parent);

        Map<String, Object> dashboardData = dashboardService.parentDashboard("john@example.com");

        assertEquals(0L, dashboardData.get("claimCount"));
        assertEquals(0L, dashboardData.get("transactionCount"));
    }

    @Test
    public void testParentDashboard_ParentNotFound() {
        when(parentRepo.findByParentEmailId("notfound@example.com")).thenReturn(null);

        ResourceNotFoundException exception = assertThrows(ResourceNotFoundException.class, () -> {
            dashboardService.parentDashboard("notfound@example.com");
        });

        assertEquals("Parent not found with email: notfound@example.com", exception.getMessage());
    }
}