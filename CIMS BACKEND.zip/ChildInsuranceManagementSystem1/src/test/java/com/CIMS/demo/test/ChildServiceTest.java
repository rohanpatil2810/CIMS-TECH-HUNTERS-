package com.CIMS.demo.test;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Collections;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.CIMS.demo.entity.Child;
import com.CIMS.demo.entity.Parent;
import com.CIMS.demo.exception.ResourceNotFoundException;
import com.CIMS.demo.repo.ChildRepo;
import com.CIMS.demo.repo.ParentRepo;
import com.CIMS.demo.service.ChildService;

@ExtendWith(MockitoExtension.class)
class ChildServiceTest {
    
    @Mock
    private ParentRepo parentRepo;
    
    @Mock
    private ChildRepo childRepo;
    
    @InjectMocks
    private ChildService childService;

    @Test
    void addChildWithParentEmail_Success() {
        // Setup parent
        Parent parent = new Parent();
        parent.setParentEmailId("parent@test.com");
        
        // Create child using no-args constructor and setters
        Child child = new Child();
        child.setChildName("Test Child");
        child.setChildGender("Male");
        child.setChildAge(5);
        child.setDateOfBirth(LocalDate.now().minusYears(5));
        child.setParent(parent);
        child.setPolicies(Collections.emptyList());
        
        when(parentRepo.findByParentEmailId("parent@test.com")).thenReturn(parent);
        when(childRepo.save(child)).thenReturn(child);
        
        Child result = childService.addChildWithParentEmail("parent@test.com", child);
        assertNotNull(result);
    }

    @Test
    void addChildWithParentEmail_SuccessWithConstructor() {
        // Setup parent
        Parent parent = new Parent();
        parent.setParentEmailId("parent@test.com");
        
        // Create child using parameterized constructor
        Child child = new Child(
            0, // ID will be generated
            "Test Child",
            "Female",
            6,
            LocalDate.now().minusYears(6),
            parent,
            Collections.emptyList()
        );
        
        when(parentRepo.findByParentEmailId("parent@test.com")).thenReturn(parent);
        when(childRepo.save(child)).thenReturn(child);
        
        Child result = childService.addChildWithParentEmail("parent@test.com", child);
        assertNotNull(result);
    }

    @Test
    void addChildWithParentEmail_ParentNotFound() {
        // Create minimal child object
        Child child = new Child();
        child.setChildName("Test Child");
        // Other fields can be null for this negative test
        
        when(parentRepo.findByParentEmailId("nonexistent@test.com")).thenReturn(null);
        
        assertThrows(ResourceNotFoundException.class, () -> {
            childService.addChildWithParentEmail("nonexistent@test.com", child);
        });
    }
}