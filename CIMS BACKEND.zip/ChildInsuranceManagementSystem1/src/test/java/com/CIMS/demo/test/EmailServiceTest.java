package com.CIMS.demo.test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

import com.CIMS.demo.exception.EmailSendFailedException;
import com.CIMS.demo.service.EmailService;

@ExtendWith(MockitoExtension.class)
public class EmailServiceTest {

    @Mock
    private JavaMailSender mailSender;

    @InjectMocks
    private EmailService emailService;

    @Test
    void sendEmail_SuccessOnFirstAttempt() throws EmailSendFailedException {
        // Arrange
        String email = "test@example.com";
        String name = "John Doe";
        doNothing().when(mailSender).send(any(SimpleMailMessage.class));

        // Act & Assert
        assertDoesNotThrow(() -> emailService.sendRegistrationEmail(email, name));
        verify(mailSender, times(1)).send(any(SimpleMailMessage.class));
    }

    @Test
    void sendEmail_SuccessOnThirdAttempt() throws EmailSendFailedException {
        // Arrange
        String email = "retry@example.com";
        String name = "Jane Smith";
        
        // First two attempts fail, third succeeds
        doThrow(new MailException("Mock failure") {})
            .doThrow(new MailException("Mock failure") {})
            .doNothing()
            .when(mailSender).send(any(SimpleMailMessage.class));

        // Act & Assert
        assertDoesNotThrow(() -> emailService.sendRegistrationEmail(email, name));
        verify(mailSender, times(3)).send(any(SimpleMailMessage.class));
    }

    
    @Test
    void sendEmail_ContainsCorrectContent() throws EmailSendFailedException {
        // Arrange
        String email = "content@test.com";
        String name = "Alice Wonder";
        doNothing().when(mailSender).send(any(SimpleMailMessage.class));

        // Act
        emailService.sendRegistrationEmail(email, name);

        // Assert
        ArgumentCaptor<SimpleMailMessage> messageCaptor = 
            ArgumentCaptor.forClass(SimpleMailMessage.class);
        verify(mailSender).send(messageCaptor.capture());
        
        SimpleMailMessage sentMessage = messageCaptor.getValue();
        assertEquals(email, sentMessage.getTo()[0]);
        assertTrue(sentMessage.getSubject().contains("Registration"));
        assertTrue(sentMessage.getText().contains(name));
    }
}