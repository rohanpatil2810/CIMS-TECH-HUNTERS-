package com.CIMS.demo.test;

//package com.CIMS.demo.ServiceTest;
//
//public class PlanServiceTest {
//
//}


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.CIMS.demo.entity.Plan;
import com.CIMS.demo.exception.ResourceNotFoundException;
import com.CIMS.demo.repo.PlanRepo;
import com.CIMS.demo.service.PlanService;

public class PlanServiceTest {

  @Mock
  private PlanRepo planRepo;

  @InjectMocks
  private PlanService planService;

  private Plan plan;

  @BeforeEach
  public void setUp() {
      MockitoAnnotations.openMocks(this);

      plan = new Plan(1, "Basic Plan", 100.0, 12);
  }

  @Test
  public void testAddPlanHere_success() {
      when(planRepo.save(plan)).thenReturn(plan);

      String result = planService.addPlanHere(plan);

      assertEquals("Plan Created Successfully", result);
      verify(planRepo, times(1)).save(plan);
  }

  @Test
  public void testAddPlanHere_failure() {
      when(planRepo.save(plan)).thenReturn(null);

      assertThrows(ResourceNotFoundException.class, () -> {
          planService.addPlanHere(plan);
      });

      verify(planRepo, times(1)).save(plan);
  }

  @Test
  public void testGetAllPlanData() {
      List<Plan> plans = Arrays.asList(
              new Plan(1, "Basic", 100.0, 12),
              new Plan(2, "Premium", 200.0, 24)
      );

      when(planRepo.findAll()).thenReturn(plans);

      List<Plan> result = planService.getAllPlanData();

      assertEquals(2, result.size());
      verify(planRepo, times(1)).findAll();
  }

  @Test
  public void testDeletePlan_success() {
      when(planRepo.findByName("Basic Plan")).thenReturn(plan);

      String result = planService.deletePlan(plan);

      assertEquals("Deleted Successfully", result);
      verify(planRepo, times(1)).delete(plan);
  }

  @Test
  public void testDeletePlan_notFound() {
      when(planRepo.findByName("Basic Plan")).thenReturn(null);

      assertThrows(ResourceNotFoundException.class, () -> {
          planService.deletePlan(plan);
      });

      verify(planRepo, never()).delete(any());
  }
}
