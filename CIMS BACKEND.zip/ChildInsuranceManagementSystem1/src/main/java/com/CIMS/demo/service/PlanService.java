package com.CIMS.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CIMS.demo.entity.Plan;
import com.CIMS.demo.exception.ResourceNotFoundException;
import com.CIMS.demo.repo.PlanRepo;

@Service
public class PlanService {

    @Autowired
    private PlanRepo planrepo;

    public String addPlanHere(Plan plan) {
        Plan savedPlan = planrepo.save(plan);
        if (savedPlan == null) {
            throw new ResourceNotFoundException("Plan creation failed. Plan data is missing.");
        }
        return "Plan Created Successfully";
    }

    public List<Plan> getAllPlanData() {
        return planrepo.findAll();
    }

    public String deletePlan(Plan plan) {
        String planName = plan.getName();
        Plan existingPlan = planrepo.findByName(planName);
        if (existingPlan == null) {
            // Throw exception instead of returning error string
            throw new ResourceNotFoundException("Plan not found with name: " + planName);
        }
        planrepo.delete(existingPlan);
        return "Deleted Successfully";
    }
}
