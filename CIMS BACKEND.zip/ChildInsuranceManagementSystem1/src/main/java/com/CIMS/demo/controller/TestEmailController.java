package com.CIMS.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestEmailController {

    @Autowired
    private JavaMailSender mailSender;

    @GetMapping("/send-test-email")
    public String sendTestEmail() {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo("2018bec001@sggs.ac.in"); // Replace with your own email
            message.setSubject("Test Email from CIMS");
            message.setText("Hello! This is a test email from your Child Insurance Management System.");
            mailSender.send(message);
            return "Test email sent successfully!";
        } catch (Exception e) {
            e.printStackTrace();
            return "Failed to send email. Check logs for error.";
        }
    }
}
