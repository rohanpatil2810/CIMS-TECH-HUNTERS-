package com.CIMS.demo.exception;

public class PolicyOperationException extends RuntimeException {
    public PolicyOperationException(String message) {
        super(message);
    }
}