package com.CIMS.demo.entity;


public class Admin {

	public String adminEmail="admin@gmail.com";
	public String adminPassword="admin@123";
	
}
