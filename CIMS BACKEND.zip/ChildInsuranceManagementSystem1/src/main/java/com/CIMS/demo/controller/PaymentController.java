
package com.CIMS.demo.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.CIMS.demo.entity.Payment;
import com.CIMS.demo.service.PaymentService;
import com.razorpay.RazorpayException;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin(origins = "*")
public class PaymentController {

    private static final Logger logger = LoggerFactory.getLogger(PaymentController.class);

    @Autowired
    private PaymentService paymentService;

    // API to create Payment (also create Razorpay Order)
    @PostMapping("/create")
    public ResponseEntity<?> createPayment(
            @RequestBody Map<String, Object> requestBody // gets the payment details from the web request
    ) throws RazorpayException {
        try {
        	// Validate required fields
            Long policyId = Long.valueOf(requestBody.get("policyId").toString());// Converts the policy number to computer format
            Long userId = Long.valueOf(requestBody.get("userId").toString());
            Double amount = Double.valueOf(requestBody.get("amount").toString());
            
            logger.info("Creating payment - PolicyId: {}, UserId: {}, Amount: {}", policyId, userId, amount);
            Payment payment = paymentService.createPayment(policyId, userId, amount); // Asks the payment user to make the payment
            return ResponseEntity.ok(payment);
        } catch (Exception e) {
            logger.error("Error creating payment: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error creating payment: " + e.getMessage());
        }
    }

    // API to update Payment Status
    @PostMapping("/update-status")
    public ResponseEntity<?> updatePaymentStatus(
            @RequestBody Map<String, String> requestBody
    ) {
        String razorpayOrderId = requestBody.get("razorpayOrderId"); // Gets the payment ID
        String status = requestBody.get("status");
        
        logger.info("Received status update request - OrderId: {}, Status: {}", razorpayOrderId, status);
        try {
            Payment updatedPayment = paymentService.updatePaymentStatus(razorpayOrderId, status);// Tells payment user to Upadte status
            if (updatedPayment != null) {
                logger.info("Status update successful - OrderId: {}, New Status: {}", razorpayOrderId, status);
                return ResponseEntity.ok(updatedPayment);
            } else {
                logger.error("Status update failed - Payment not found for OrderId: {}", razorpayOrderId);
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("Payment not found for order ID: " + razorpayOrderId);
            }
        } catch (Exception e) {
            logger.error("Error updating payment status - OrderId: {}, Error: {}", razorpayOrderId, e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error updating payment status: " + e.getMessage());
        }
    }

    @PostMapping("/verify")
    public ResponseEntity<?> verifyPayment(
            @RequestBody Map<String, String> requestBody
    ) {
    	// Gets payment verification details
        String razorpayOrderId = requestBody.get("razorpayOrderId");
        String razorpayPaymentId = requestBody.get("razorpayPaymentId");
        String razorpaySignature = requestBody.get("razorpaySignature");
        
        logger.info("Received payment verification request - OrderId: {}", razorpayOrderId);
        try {
            boolean isVerified = paymentService.verifyPayment(razorpayOrderId, razorpayPaymentId, razorpaySignature);
            // If payment is good
            if (isVerified) {
                logger.info("Payment verified successfully for OrderId: {}", razorpayOrderId);
                return ResponseEntity.ok(Map.of("verified", true)); // Says "Yes, this payment is real"
            } else {
                logger.error("Payment verification failed for OrderId: {}", razorpayOrderId);
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("verified", false, "message", "Payment verification failed"));
            }
        } catch (Exception e) {
            logger.error("Error verifying payment - OrderId: {}, Error: {}", razorpayOrderId, e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("verified", false, "message", "Error verifying payment: " + e.getMessage()));
        }
    }
}