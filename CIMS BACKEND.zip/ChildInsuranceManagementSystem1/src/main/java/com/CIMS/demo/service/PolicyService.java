package com.CIMS.demo.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.CIMS.demo.entity.Child;
import com.CIMS.demo.entity.Parent;
import com.CIMS.demo.entity.Plan;
import com.CIMS.demo.entity.Policy;
import com.CIMS.demo.exception.ResourceNotFoundException;
import com.CIMS.demo.repo.ChildRepo;
import com.CIMS.demo.repo.ParentRepo;
import com.CIMS.demo.repo.PlanRepo;
import com.CIMS.demo.repo.PolicyRepo;

@Service
public class PolicyService {

    @Autowired
    private PolicyRepo policyRepository;

    @Autowired
    private ParentRepo parentRepository;
    
    @Autowired
    private ChildRepo childRepository;

    @Autowired
    private PlanRepo planRepository;

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private TwilioService twilioService;
    
    public ResponseEntity<String> buyPolicy(Policy policy) {
        if (policy == null || policy.getParent() == null || policy.getChild() == null || policy.getPlan() == null) {
            throw new IllegalArgumentException("Incomplete policy details provided.");
        }

        // 1. Fetch parent by email
        String parentEmail = policy.getParent().getParentEmailId();
        Parent existingParent = parentRepository.findByParentEmailId(parentEmail);
        if (existingParent == null) {
            throw new ResourceNotFoundException("Parent with email " + parentEmail + " not found.");
        }

        // 2. Find the child under that parent
        Child matchedChild = existingParent.getChildren().stream()
            .filter(child -> child.getChildName().equalsIgnoreCase(policy.getChild().getChildName()))
            .findFirst()
            .orElseThrow(() -> new ResourceNotFoundException("Child not found under this parent"));

        // 3. Find plan by name
        Plan planFromDb = planRepository.findByNameIgnoreCase(policy.getPlan().getName())
            .orElseThrow(() -> new ResourceNotFoundException("Plan not found with name: " + policy.getPlan().getName()));

        // 4. Set associations
        policy.setParent(existingParent);
        policy.setChild(matchedChild);
        policy.setPlan(planFromDb);

        // 5. Set start and end dates
        LocalDate startDate = policy.getStartDate();
        if (startDate == null) {
            startDate = LocalDate.now();
            policy.setStartDate(startDate);
        }
        LocalDate endDate = startDate.plusMonths(planFromDb.getCoverageMonths());
        policy.setEndDate(endDate);

        // 6. Calculate premium
        double premium = planFromDb.getMonthlyPremium();
        policy.setMonthlyPremium(premium);

        // 7. Save policy
        Policy savedPolicy = policyRepository.save(policy);

        // 8. Send confirmation email with all details
        sendPolicyConfirmationEmail(savedPolicy);

        return ResponseEntity.status(201).body("Congratulations! Your policy has been successfully created.");
    }

    private void sendPolicyConfirmationEmail(Policy policy) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(policy.getParent().getParentEmailId());
        message.setSubject("Policy Purchase Confirmation - CIMS");
        
        // Format dates
        String startDate = policy.getStartDate().toString();
        String endDate = policy.getEndDate().toString();
        
        // Build email content
        String emailContent = String.format(
            "Dear %s,\n\n" +
            "Thank you for purchasing an insurance policy with CIMS. Below are your policy details:\n\n" +
            "🔹 Policy ID: %d\n" +
            "🔹 Parent ID: %d\n" +
            "🔹 Child ID: %d\n" +
            "🔹 Child Name: %s\n" +
            "🔹 Plan Name: %s\n" +
            "🔹 Coverage Amount: ₹%.2f per month\n" +
            "🔹 Coverage Period: %d months\n" +
            "🔹 Start Date: %s\n" +
            "🔹 End Date: %s\n\n" +
            "Your policy is now active. Please keep this information for your records.\n\n" +
            "If you have any questions, please contact our support team.\n\n" +
            "Best regards,\n" +
            "CIMS Team",
            policy.getParent().getParentName(),
            policy.getId(),
            policy.getParent().getParent_Id(),
            policy.getChild().getChildId(),
            policy.getChild().getChildName(),
            policy.getPlan().getName(),
            policy.getMonthlyPremium(),
            policy.getPlan().getCoverageMonths(),
            startDate,
            endDate
        );
        
        message.setText(emailContent);
        mailSender.send(message);
    }
    
    
   
//    public ResponseEntity<String> buyPolicy(Policy policy) {
//        if (policy == null || policy.getParent() == null || policy.getChild() == null || policy.getPlan() == null) {
//            throw new IllegalArgumentException("Incomplete policy details provided.");
//        }
//
//        // 1. Fetch parent by email
//        String parentEmail = policy.getParent().getParentEmailId();
//        Parent existingParent = parentRepository.findByParentEmailId(parentEmail);
//        if (existingParent == null) {
//            throw new ResourceNotFoundException("Parent with email " + parentEmail + " not found.");
//        }
//
//        // 2. Find the child under that parent
//        Child matchedChild = existingParent.getChildren().stream()
//            .filter(child -> child.getChildName().equalsIgnoreCase(policy.getChild().getChildName()))
//            .findFirst()
//            .orElseThrow(() -> new ResourceNotFoundException("Child not found under this parent"));
//
//        // 3. Find plan by name
//        Plan planFromDb = planRepository.findByNameIgnoreCase(policy.getPlan().getName())
//            .orElseThrow(() -> new ResourceNotFoundException("Plan not found with name: " + policy.getPlan().getName()));
//
//        // 4. Set associations
//        policy.setParent(existingParent);
//        policy.setChild(matchedChild);
//        policy.setPlan(planFromDb);
//
//        // 5. Set start and end dates
//        LocalDate startDate = policy.getStartDate();
//        if (startDate == null) {
//            startDate = LocalDate.now(); // default to current date if not provided
//            policy.setStartDate(startDate);
//        }
//        LocalDate endDate = startDate.plusMonths(planFromDb.getCoverageMonths());
//        policy.setEndDate(endDate);
//
//        // 6. Age-based premium calculation
//        int age = LocalDate.now().getYear() - matchedChild.getDateOfBirth().getYear();
//        double premium = planFromDb.getMonthlyPremium();
////        if (age < 5) {
////            premium *= 0.9; // 10% discount
////        } else if (age > 12) {
////            premium *= 1.2; // 20% extra
////        }
//        policy.setMonthlyPremium(premium);
//
//        // 7. Save policy
//        policyRepository.save(policy);
//
//        return ResponseEntity.status(201).body("Congratulations! Your policy has been successfully created.");
//    }
    
    public String updatePremiumNew(Policy inputPolicy) {
        if (inputPolicy == null || inputPolicy.getParent() == null || inputPolicy.getChild() == null || inputPolicy.getPlan() == null) {
            throw new IllegalArgumentException("Policy must include Parent, Child, and Plan.");
        }

        // Step 1: Fetch the parent using email
        Parent parent = parentRepository.findByParentEmailId(inputPolicy.getParent().getParentEmailId());
        if (parent == null) {
            throw new ResourceNotFoundException("Parent not found with email: " + inputPolicy.getParent().getParentEmailId());
        }

        // Step 2: Fetch the child that belongs to the given parent
        Child child = childRepository.findByChildNameAndParent(inputPolicy.getChild().getChildName(), parent)
                .orElseThrow(() -> new ResourceNotFoundException("Child '" + inputPolicy.getChild().getChildName() + "' not found for this parent."));

        // Step 3: Fetch the plan
        Plan plan = planRepository.findByName(inputPolicy.getPlan().getName());
        if (plan == null) {
            throw new ResourceNotFoundException("Plan not found with name: " + inputPolicy.getPlan().getName());
        }

        // Step 4: Fetch the distinct policy
        List<Policy> policies = policyRepository.findByParentAndChildAndPlan(parent, child, plan);
        if (policies.isEmpty()) {
            throw new ResourceNotFoundException("Policy not found for the given parent, child, and plan.");
        }

        Policy policy = policies.get(0);

        // Step 5: Ensure startDate exists
        LocalDate startDate = policy.getStartDate();
        if (startDate == null) {
            throw new IllegalStateException("Policy start date is missing.");
        }

        int coverageMonths = plan.getCoverageMonths();
        LocalDate now = LocalDate.now();
        LocalDate endDate = startDate.plusMonths(coverageMonths);
        policy.setEndDate(endDate); // ensure it's set

        if (now.isAfter(endDate)) {
            return "Policy has already expired.";
        }

        long monthsElapsed = ChronoUnit.MONTHS.between(startDate, now);
        if (monthsElapsed >= coverageMonths) {
            return "All premiums have already been paid.";
        }

        // Step 6: Add base monthly premium
        double baseMonthly = plan.getMonthlyPremium();
        double currentPremium = policy.getMonthlyPremium() + baseMonthly;
        policy.setMonthlyPremium(currentPremium);

        // Step 7: Apply compound interest yearly
        if ((monthsElapsed + 1) % 12 == 0) {
            double rate = plan.getName().equalsIgnoreCase("EduHealth Shield") ? 0.08 : 0.07;
            double compoundedPremium = currentPremium * Math.pow(1 + rate, 1);
            policy.setMonthlyPremium(compoundedPremium);
        }

        policyRepository.save(policy);

        return "Premium paid for month " + (monthsElapsed + 1) + " for " + child.getChildName()
                + " under " + parent.getParentName() + "'s policy. Updated premium: ₹" + policy.getMonthlyPremium();
    }
  

    // Check if a policy is expired or not
    public boolean isPolicyExpired(Policy policy) {
        return policy.getEndDate().isBefore(LocalDate.now());
    }
    
    // This method will run automatically on 1st day of every month at 9 AM
    @Scheduled(cron = "* * * * * ?")  // 1st of every month at 9AM
    public void sendMonthlyPremiumReminders() {
        LocalDate today = LocalDate.now();
        List<Policy> activePolicies = policyRepository.findByEndDateAfter(today);
        
        for (Policy policy : activePolicies) {
            sendMonthlyPremiumNotification(policy);
        }
    }

    // Separate method for Monthly Premium Reminder
    public void sendMonthlyPremiumNotification(Policy policy) {
        String childName = policy.getChild().getChildName();
        String planName = policy.getPlan().getName();
        String parentEmail = policy.getParent().getParentEmailId();
        String parentPhone = policy.getParent().getContactNumber();
        double premium = policy.getMonthlyPremium();

        // Email
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(parentEmail);
        message.setSubject("Monthly Premium Reminder for Your Child's Insurance - CIMS");
        message.setText("Dear Parent,\n\n"
            + "We hope this message finds you well.\n\n"
            + "This is a gentle reminder to pay the monthly premium of ₹" + premium + " for your child, " + childName
            + ", under the '" + planName + "' plan.\n\n"
            + "Ensuring timely payment keeps the insurance policy active without interruptions.\n\n"
            + "Thank you for trusting CIMS to protect your family.\n\n"
            + "Warm regards,\nCIMS Support Team");
        mailSender.send(message);

        // WhatsApp
        String formattedPhone = formatPhoneNumber(parentPhone);
        String whatsappMessage = "Reminder: ₹" + premium + " premium due for your child " + childName +
                                  " (" + planName + " Plan). Please pay soon to keep the insurance active. - CIMS";
        twilioService.sendWhatsAppMessage(formattedPhone, whatsappMessage);
    }

    // This method runs automatically every day at 9AM
    @Scheduled(cron = "0 0 9 * * ?")
    public void checkExpiringPolicies() {
        LocalDate currentDate = LocalDate.now();
        LocalDate renewalReminderDate = currentDate.plusDays(7); // Check for policies expiring within 7 days

        // 1. Find all policies that will expire before the renewal reminder date
        List<Policy> expiringPolicies = policyRepository.findByEndDateBefore(renewalReminderDate);

        // 2. Send renewal notification for each expiring policy
        for (Policy policy : expiringPolicies) {
            sendRenewalNotifications(policy);
        }
    }

    // Send renewal notifications (Email + WhatsApp)
    public void sendRenewalNotifications(Policy policy) {
        String childName = policy.getChild().getChildName();
        String parentEmail = policy.getParent().getParentEmailId();
        String parentPhoneNumber = policy.getParent().getContactNumber();

        // Send both email and WhatsApp notifications
        sendEmailReminder(parentEmail, childName, policy.getPlan().getName());
        sendWhatsAppReminder(parentPhoneNumber, childName, policy.getPlan().getName());
    }

    // Send email reminder
    public void sendEmailReminder(String email, String childName, String planName) {
    	SimpleMailMessage message = new SimpleMailMessage();
    	message.setTo(email);
    	message.setSubject("Important: Policy Renewal Reminder for " + childName);
    	message.setText("Dear Parent,\n\n"
    	    + "We hope you and your family are doing well.\n\n"
    	    + "This is a friendly reminder that your child, " + childName + "'s insurance policy under the '" + planName + "' plan is expiring soon.\n\n"
    	    + "To ensure continued protection, please renew the policy before the expiry date.\n\n"
    	    + "If you need any assistance, feel free to reach out to our support team.\n\n"
    	    + "Thank you for choosing CIMS!\n\n"
    	    + "Warm regards,\nCIMS Support Team");
    	mailSender.send(message);
    }

    // Send WhatsApp reminder using Twilio
    public void sendWhatsAppReminder(String phoneNumber, String childName, String planName) {
        String formattedPhone = formatPhoneNumber(phoneNumber);
        String message = "Dear Parent, your child " + childName + " has a policy with plan " + planName + " that is about to expire. Please renew it soon.";
        twilioService.sendWhatsAppMessage(formattedPhone, message);
    }
    
    // Helper method to format phone number into E.164 WhatsApp format
 // format phone number correctly
    private String formatPhoneNumber(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.isEmpty()) {
            throw new IllegalArgumentException("Phone number is empty");
        }
        phoneNumber = phoneNumber.trim();
        if (!phoneNumber.startsWith("+")) {
            phoneNumber = "+91" + phoneNumber;
        }
        return "whatsapp:" + phoneNumber;
    }

}
