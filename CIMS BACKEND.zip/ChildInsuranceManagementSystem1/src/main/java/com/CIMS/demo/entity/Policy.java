package com.CIMS.demo.entity;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Policy {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

	@ManyToOne
	@JsonBackReference("policy-parent")
	@JoinColumn(name = "parent_id")
	private Parent parent;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JsonBackReference("child-policy")
	@JoinColumn(name = "child_id")
	private Child child;

	@ManyToOne
	@JoinColumn(name = "plan_id")
	private Plan plan;

    private LocalDate startDate;
    private LocalDate endDate;


    @OneToMany(mappedBy = "policy")
    @JsonManagedReference("policy-claim")
    private List<Claim> claims;

    public boolean isExpired() {
        return endDate != null && endDate.isBefore(LocalDate.now());
    }
    
    public Policy(){}

	public Policy(Long id, Child child, Plan plan, LocalDate startDate, LocalDate endDate, Parent parent,
			List<Claim> claims) {
		super();
		this.id = id;
		this.child = child;
		this.plan = plan;
		this.startDate = startDate;
		this.endDate = endDate;
		this.parent = parent;
		this.claims = claims;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Child getChild() {
		return child;
	}

	public void setChild(Child child) {
		this.child = child;
	}

	public Plan getPlan() {
		return plan;
	}

	public void setPlan(Plan plan) {
		this.plan = plan;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public List<Claim> getClaims() {
		return claims;
	}

	public void setClaims(List<Claim> claims) {
		this.claims = claims;
	}
	private double monthlyPremium;

	public double getMonthlyPremium() {
	    return monthlyPremium;
	}

	public void setMonthlyPremium(double monthlyPremium) {
	    this.monthlyPremium = monthlyPremium;
	}


	@Override
	public String toString() {
		return "Policy [id=" + id + ", child=" + child + ", plan=" + plan + ", startDate=" + startDate + ", endDate="
				+ endDate + ", parent=" + parent + ", claims=" + claims + "]";
	}
    
    
    
    
    
}
