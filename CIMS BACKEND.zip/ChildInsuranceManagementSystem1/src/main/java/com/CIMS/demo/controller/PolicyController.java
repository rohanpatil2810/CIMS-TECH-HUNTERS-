package com.CIMS.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.CIMS.demo.entity.Policy;
import com.CIMS.demo.service.PolicyService;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/policy")
public class PolicyController {

    @Autowired
    PolicyService policyService;

    @PostMapping("/buypolicy")
    public ResponseEntity<String> buyPolicyForChild(@RequestBody Policy policy) {
        //Policy purchasedPolicy = policyService.buyPolicy(policy);
//        return ResponseEntity.status(201).body(purchasedPolicy); // 201 Created
    	return policyService.buyPolicy(policy);
    }
    
    
    @PutMapping("/updatepremium")
    public ResponseEntity<String> updatePremiumNew(@RequestBody Policy policy) {
        String result = policyService.updatePremiumNew(policy);
        return ResponseEntity.ok(result);
    }


    @GetMapping("/isExpired")
    public ResponseEntity<Boolean> isPolicyExpired(@RequestBody Policy policy) {
        boolean expired = policyService.isPolicyExpired(policy);
        return ResponseEntity.ok(expired); // HTTP 200 OK
    }
}
