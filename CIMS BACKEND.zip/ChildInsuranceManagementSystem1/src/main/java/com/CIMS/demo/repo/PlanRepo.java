package com.CIMS.demo.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CIMS.demo.entity.Plan;

public interface PlanRepo extends JpaRepository<Plan, Integer>{

	public Plan findByName(String planName);
	Optional<Plan> findByNameIgnoreCase(String name);

}
