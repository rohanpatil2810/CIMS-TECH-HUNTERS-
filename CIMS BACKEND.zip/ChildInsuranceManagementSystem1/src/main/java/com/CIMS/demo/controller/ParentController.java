package com.CIMS.demo.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.CIMS.demo.dto.ParentChildDTO;
import com.CIMS.demo.entity.Parent;
import com.CIMS.demo.service.ParentService;

@RestController
@CrossOrigin(origins = "*")
//@CrossOrigin(origins = "http://localhost:3000") // Allow React frontend to access
@RequestMapping("/api/user")
public class ParentController {
	
	@Autowired
	private ParentService parentservice;
	
	@PostMapping("/registration")
	private ResponseEntity<String> parentRegistration(@RequestBody Parent parent) {
	    return parentservice.registerParentHere(parent);
	}
	

	@PostMapping("/login")
	public ResponseEntity<Map<String, Object>> parentLogin(@RequestBody Parent parent) {
	    return parentservice.loginAndReturnDashboard(parent);
	}
	

	@GetMapping("/changepassword")
	public ResponseEntity<String> parentChangePassword(@RequestParam("email") String email, @RequestParam("pw") String pw) {
	    return parentservice.changePassword(email, pw);
	}	
	
	
	@PostMapping("/updateemail")
	public ResponseEntity<String> updateEmailId(@RequestBody Map<String, String> emailMap) {
	    String oldEmail = emailMap.get("oldEmail");
	    String newEmail = emailMap.get("newEmail");
	    return parentservice.updateParentEmail(oldEmail, newEmail);
	}

	// Endpoint to fetch all parents and their children's names
    @GetMapping("/allParentsWithChildren")
    public ResponseEntity<List<ParentChildDTO>> getAllParentsWithChildren() {
        List<ParentChildDTO> parentChildList = parentservice.getAllParentsWithChildren();
        return ResponseEntity.ok(parentChildList);
    }
    
    @GetMapping("/plans")
    public ResponseEntity<List<String>> getPlanNamesByParentEmail(@RequestParam("email") String email) {
        List<String> planNames = parentservice.getPlanNamesOfParent(email);
        return ResponseEntity.ok(planNames);
    }
	
}