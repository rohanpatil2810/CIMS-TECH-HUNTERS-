package com.CIMS.demo.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.CIMS.demo.entity.Claim;
import com.CIMS.demo.entity.Parent;
import com.CIMS.demo.entity.Policy;
import com.CIMS.demo.exception.InvalidClaimException;
import com.CIMS.demo.exception.ResourceNotFoundException;
import com.CIMS.demo.repo.ClaimRepo;
import com.CIMS.demo.repo.ParentRepo;
import com.CIMS.demo.repo.PolicyRepo;

@Service
@Transactional
public class ClaimService {

    @Autowired
    private ClaimRepo claimRepository;
    
    @Autowired
    private ParentRepo parentRepository;
    
    @Autowired
    private PolicyRepo policyRepository;
    
    @Autowired
    private EmailService emailService;

    public ResponseEntity<String> claimHere(Claim claim) {
        // Basic validation
        if (claim == null) {
            throw new InvalidClaimException("Claim request cannot be null");
        }
        
        if (claim.getParent() == null || claim.getParent().getParent_Id() == 0) {
            throw new InvalidClaimException("Parent information is required");
        }
        
        if (claim.getPolicy() == null || claim.getPolicy().getId() == null) {
            throw new InvalidClaimException("Policy information is required");
        }
        
        if (claim.getReason() == null || claim.getReason().trim().isEmpty()) {
            throw new InvalidClaimException("Claim reason cannot be empty");
        }

        // Validate parent exists
        Parent parent = parentRepository.findById(claim.getParent().getParent_Id())
            .orElseThrow(() -> new ResourceNotFoundException(
                "Parent not found with ID: " + claim.getParent().getParent_Id()));

        // Validate policy exists (using Long for policy ID)
        Policy policy = policyRepository.findById(claim.getPolicy().getId())
            .orElseThrow(() -> new ResourceNotFoundException(
                "Policy not found with ID: " + claim.getPolicy().getId()));

        // Validate policy belongs to parent (using int comparison)
        if (policy.getParent() == null || policy.getParent().getParent_Id() != parent.getParent_Id()) {
            throw new InvalidClaimException("Policy does not belong to the specified parent");
        }

        // Check for duplicate claims (using policy ID instead of Policy object)
        if (claimRepository.existsByPolicyIdAndStatus(policy.getId(), "Pending")) {
            throw new InvalidClaimException("There is already a pending claim for this policy");
        }

        // Set claim details
        claim.setDate(LocalDate.now());
        claim.setStatus("Pending");
        claim.setParent(parent);
        claim.setPolicy(policy);

        // Save the claim
        Claim savedClaim = claimRepository.save(claim);
        
        return ResponseEntity.status(HttpStatus.CREATED)
            .body("Claim submitted successfully. Claim ID: " + savedClaim.getClaimId());
    }
    
    
    public ResponseEntity<List<Claim>> getAllPendingClaims() {
        List<Claim> pendingClaims = claimRepository.findByStatus("Pending");
        return ResponseEntity.ok(pendingClaims);
    }
    
    
    public ResponseEntity<String> updateClaimStatus(Integer claimId, String status) {
        Claim claim = claimRepository.findById(claimId)
            .orElseThrow(() -> new ResourceNotFoundException("Claim not found with ID: " + claimId));

        if (!"Pending".equalsIgnoreCase(claim.getStatus())) {
            return ResponseEntity.badRequest().body("Claim is already processed");
        }

        claim.setStatus(status);
        claimRepository.save(claim);

        // ✅ Send email to parent
        Parent parent = claim.getParent();
        String parentEmail = parent.getParentEmailId();
        String parentName = parent.getParentName();

        try {
            emailService.sendClaimStatusEmail(parentEmail, parentName, status); // You must implement this method
        } catch (Exception e) {
            System.err.println("❌ Failed to send claim status email: " + e.getMessage());
        }

        return ResponseEntity.ok("Claim " + status.toLowerCase() + " successfully and email sent.");
    }


//    public ResponseEntity<String> updateClaimStatus(Integer claimId, String status) {
//        Claim claim = claimRepository.findById(claimId)
//            .orElseThrow(() -> new ResourceNotFoundException("Claim not found with ID: " + claimId));
//        
//        if (!"Pending".equals(claim.getStatus())) {
//            return ResponseEntity.badRequest().body("Claim is already processed");
//        }
//        
//        claim.setStatus(status);
//        claimRepository.save(claim);
//        
//        return ResponseEntity.ok("Claim " + status.toLowerCase() + " successfully");
//    }
    
}




//package com.CIMS.demo.service;
//
//import java.time.LocalDate;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.CIMS.demo.entity.Claim;
//import com.CIMS.demo.entity.Parent;
//import com.CIMS.demo.entity.Policy;
//import com.CIMS.demo.exception.InvalidClaimException;
//import com.CIMS.demo.exception.ResourceNotFoundException;
//import com.CIMS.demo.repo.ClaimRepo;
//import com.CIMS.demo.repo.ParentRepo;
//import com.CIMS.demo.repo.PolicyRepo;
//
//@Service
//@Transactional
//public class ClaimService {
//
//    @Autowired
//    private ClaimRepo claimRepository;
//    
//    @Autowired
//    private ParentRepo parentRepository;
//    
//    @Autowired
//    private PolicyRepo policyRepository;
//
//    public ResponseEntity<String> claimHere(Claim claim) {
//        // Basic validation
//        if (claim == null) {
//            throw new InvalidClaimException("Claim request cannot be null");
//        }
//        
//        if (claim.getParent() == null || claim.getParent().getParent_Id() == 0) {
//            throw new InvalidClaimException("Parent information is required");
//        }
//        
//        if (claim.getPolicy() == null || claim.getPolicy().getId() == null) {
//            throw new InvalidClaimException("Policy information is required");
//        }
//        
//        if (claim.getReason() == null || claim.getReason().trim().isEmpty()) {
//            throw new InvalidClaimException("Claim reason cannot be empty");
//        }
//
//        // Validate parent exists
//        Parent parent = parentRepository.findById(claim.getParent().getParent_Id())
//            .orElseThrow(() -> new ResourceNotFoundException(
//                "Parent not found with ID: " + claim.getParent().getParent_Id()));
//
//        // Validate policy exists (using Long for policy ID)
//        Policy policy = policyRepository.findById(claim.getPolicy().getId())
//            .orElseThrow(() -> new ResourceNotFoundException(
//                "Policy not found with ID: " + claim.getPolicy().getId()));
//
//        // Validate policy belongs to parent (using int comparison)
//        if (policy.getParent() == null || policy.getParent().getParent_Id() != parent.getParent_Id()) {
//            throw new InvalidClaimException("Policy does not belong to the specified parent");
//        }
//
//        // Check for duplicate claims (using policy ID instead of Policy object)
//        if (claimRepository.existsByPolicyIdAndStatus(policy.getId(), "Pending")) {
//            throw new InvalidClaimException("There is already a pending claim for this policy");
//        }
//
//        // Set claim details
//        claim.setDate(LocalDate.now());
//        claim.setStatus("Pending");
//        claim.setParent(parent);
//        claim.setPolicy(policy);
//
//        // Save the claim
//        Claim savedClaim = claimRepository.save(claim);
//        
//        return ResponseEntity.status(HttpStatus.CREATED)
//            .body("Claim submitted successfully. Claim ID: " + savedClaim.getClaimId());
//    }
//    
//    
//    public ResponseEntity<List<Claim>> getAllPendingClaims() {
//        List<Claim> pendingClaims = claimRepository.findByStatus("Pending");
//        return ResponseEntity.ok(pendingClaims);
//    }
//
//    public ResponseEntity<String> updateClaimStatus(Integer claimId, String status) {
//        Claim claim = claimRepository.findById(claimId)
//            .orElseThrow(() -> new ResourceNotFoundException("Claim not found with ID: " + claimId));
//        
//        if (!"Pending".equals(claim.getStatus())) {
//            return ResponseEntity.badRequest().body("Claim is already processed");
//        }
//        
//        claim.setStatus(status);
//        claimRepository.save(claim);
//        
//        return ResponseEntity.ok("Claim " + status.toLowerCase() + " successfully");
//    }
//    
//}
