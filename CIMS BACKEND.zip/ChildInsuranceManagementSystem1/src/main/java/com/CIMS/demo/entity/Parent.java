package com.CIMS.demo.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Parent {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int parent_Id;
	private String parentName;
	private String parentGender;
	
	@Column(unique = true, nullable = false)
	private String parentEmailId;
	
	@Column(nullable = false)
	private String parentPw;
	
	@Column(nullable = false)
	private String contactNumber;
	

	@OneToMany(mappedBy = "parent", cascade = CascadeType.ALL)
    @JsonManagedReference("parent-child")
    private List<Child> children;

    @OneToMany(mappedBy = "parent")
    @JsonManagedReference
    private List<Transaction> transactions;

    @OneToMany(mappedBy = "parent")
    @JsonManagedReference("parent-claim")
    private List<Claim> claims;
    

    public Parent(){}
	public Parent(int parent_Id, String parentName, String parentGender, String parentEmailId, String parentPw,
			String contactNumber, List<Child> children, List<Transaction> transactions, List<Claim> claims) {
		super();
		this.parent_Id = parent_Id;
		this.parentName = parentName;
		this.parentGender = parentGender;
		this.parentEmailId = parentEmailId;
		this.parentPw = parentPw;
		this.contactNumber = contactNumber;
		this.children = children;
		this.transactions = transactions;
		this.claims = claims;
	}

	public int getParent_Id() {
		return parent_Id;
	}

	public void setParent_Id(int parent_Id) {
		this.parent_Id = parent_Id;
	}

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	public String getParentGender() {
		return parentGender;
	}

	public void setParentGender(String parentGender) {
		this.parentGender = parentGender;
	}

	public String getParentEmailId() {
		return parentEmailId;
	}

	public void setParentEmailId(String parentEmailId) {
		this.parentEmailId = parentEmailId;
	}

	public String getParentPw() {
		return parentPw;
	}

	public void setParentPw(String parentPw) {
		this.parentPw = parentPw;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public List<Child> getChildren() {
		return children;
	}

	public void setChildren(List<Child> children) {
		this.children = children;
	}

	public List<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}

	public List<Claim> getClaims() {
		return claims;
	}

	public void setClaims(List<Claim> claims) {
		this.claims = claims;
	}
	@Override
	public String toString() {
		return "Parent [parent_Id=" + parent_Id + ", parentName=" + parentName + ", parentGender=" + parentGender
				+ ", parentEmailId=" + parentEmailId + ", parentPw=" + parentPw + ", contactNumber=" + contactNumber
				+ ", children=" + children + ", transactions=" + transactions + ", claims=" + claims + "]";
	}

    
//	@OneToMany(cascade = CascadeType.ALL,targetEntity = Policy.class)
//	@JsonManagedReference
//	List<Policy> policies;
	
//	@OneToMany(cascade = CascadeType.ALL,targetEntity=Child.class)
//	@JsonManagedReference
//	List<Child> childs;
//	
//	@ManyToMany(cascade = CascadeType.ALL,targetEntity = Policy.class)
//	@JsonManagedReference
//	List<Policy> policies;
//	
//	@OneToOne(cascade=CascadeType.ALL,targetEntity = Claim.class)
//	@JsonManagedReference
//	Claim claim;
	
	
	
	
}
