package com.CIMS.demo.entity;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Transaction {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int trasactionId;
    private double amount;
    private LocalDate trasactionDate;
    private String transactionStatus; // SUCCESS, FAILED
    private String transactionMode; //Rezorpay
    
    @ManyToOne
    @JsonBackReference
	@JoinColumn(name = "parent_id")
    private Parent parent;
    
    @ManyToOne
    private Policy policy;
    
    Transaction(){}

	public Transaction(int trasactionId, double amount, LocalDate trasactionDate, String transactionStatus,
			String transactionMode, Parent parent, Policy policy) {
		super();
		this.trasactionId = trasactionId;
		this.amount = amount;
		this.trasactionDate = trasactionDate;
		this.transactionStatus = transactionStatus;
		this.transactionMode = transactionMode;
		this.parent = parent;
		this.policy = policy;
	}

	public int getTrasactionId() {
		return trasactionId;
	}

	public void setTrasactionId(int trasactionId) {
		this.trasactionId = trasactionId;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public LocalDate getTrasactionDate() {
		return trasactionDate;
	}

	public void setTrasactionDate(LocalDate trasactionDate) {
		this.trasactionDate = trasactionDate;
	}

	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public String getTransactionMode() {
		return transactionMode;
	}

	public void setTransactionMode(String transactionMode) {
		this.transactionMode = transactionMode;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public Policy getPolicy() {
		return policy;
	}

	public void setPolicy(Policy policy) {
		this.policy = policy;
	}

	@Override
	public String toString() {
		return "Transaction [trasactionId=" + trasactionId + ", amount=" + amount + ", trasactionDate=" + trasactionDate
				+ ", transactionStatus=" + transactionStatus + ", transactionMode=" + transactionMode + ", parent="
				+ parent + ", policy=" + policy + "]";
	}
    
    
}
