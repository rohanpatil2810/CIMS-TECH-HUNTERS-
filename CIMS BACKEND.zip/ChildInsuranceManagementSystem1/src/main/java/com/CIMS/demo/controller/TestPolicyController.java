package com.CIMS.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.CIMS.demo.entity.Policy;
import com.CIMS.demo.service.PolicyService;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/test")
public class TestPolicyController {

    @Autowired
    private PolicyService policyService;

    @PostMapping("/send-renewal-email")
    public String sendRenewalEmail(@RequestBody Policy policy) {
        try {
            policyService.sendRenewalNotifications(policy);
            return "Renewal reminder email sent successfully!";
        } catch (Exception e) {
            e.printStackTrace();
            return "Error occurred while sending renewal reminder.";
        }
    }
}
