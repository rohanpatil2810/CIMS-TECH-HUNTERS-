package com.CIMS.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Plan {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int planId;
    private String name;
    private double monthlyPremium;
    private int coverageMonths;
    
    public Plan(){}

	public Plan(int planId, String name, double monthlyPremium, int coverageMonths) {
		super();
		this.planId = planId;
		this.name = name;
		this.monthlyPremium = monthlyPremium;
		this.coverageMonths = coverageMonths;
	}

	public int getPlanId() {
		return planId;
	}

	public void setPlanId(int planId) {
		this.planId = planId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getMonthlyPremium() {
		return monthlyPremium;
	}

	public void setMonthlyPremium(double monthlyPremium) {
		this.monthlyPremium = monthlyPremium;
	}

	public int getCoverageMonths() {
		return coverageMonths;
	}

	public void setCoverageMonths(int coverageMonths) {
		this.coverageMonths = coverageMonths;
	}

	@Override
	public String toString() {
		return "Plan [planId=" + planId + ", name=" + name + ", monthlyPremium=" + monthlyPremium + ", coverageMonths="
				+ coverageMonths + "]";
	}
    
    
}
