package com.CIMS.demo.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.CIMS.demo.entity.Admin;
import com.CIMS.demo.exception.InvalidCredentialsException;

@Service
public class AdminService {

    private final Admin staticAdmin = new Admin(); // hardcoded admin from entity

    public ResponseEntity<String> adminLoginHere(Admin admin) {
        if (staticAdmin.adminEmail.equalsIgnoreCase(admin.adminEmail)) {
            if (staticAdmin.adminPassword.equals(admin.adminPassword)) {
                return ResponseEntity.ok("Login Successful");
            } else {
                throw new InvalidCredentialsException("Incorrect password.");
            }
        } else {
            throw new InvalidCredentialsException("Admin email not found.");
        }
    }
}
