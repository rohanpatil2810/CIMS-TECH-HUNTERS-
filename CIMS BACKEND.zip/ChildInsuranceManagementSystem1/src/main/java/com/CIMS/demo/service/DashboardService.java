package com.CIMS.demo.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CIMS.demo.entity.Child;
import com.CIMS.demo.entity.Parent;
import com.CIMS.demo.exception.ResourceNotFoundException;
import com.CIMS.demo.repo.ChildRepo;
import com.CIMS.demo.repo.ClaimRepo;
import com.CIMS.demo.repo.ParentRepo;
import com.CIMS.demo.repo.PolicyRepo;

@Service
public class DashboardService {

    @Autowired
    ParentRepo parentrepo;

    @Autowired
    ChildRepo childrepo;

    @Autowired
    PolicyRepo policyrepo;

    @Autowired 
    ClaimRepo claimrepo;

    public Map<String, Object> parentDashboard(String email) {
        Map<String, Object> dashboardData = new HashMap<>();

        Parent parent = parentrepo.findByParentEmailId(email);
        if (parent == null) {
            throw new ResourceNotFoundException("Parent not found with email: " + email);
        }

        List<String> childrenNames = parent.getChildren()
            .stream()
            .map(Child::getChildName)
            .collect(Collectors.toList());

        List<String> plan = parent.getChildren()
            .stream()
            .flatMap(child -> child.getPolicies().stream().map(p -> p.getPlan().getName()))
            .collect(Collectors.toList());

        long parentClaimCount = parent.getClaims() != null ? parent.getClaims().size() : 0;
        long txnCount = parent.getTransactions() != null ? parent.getTransactions().size() : 0;

        dashboardData.put("parentName", parent.getParentName());
        dashboardData.put("email", parent.getParentEmailId());
        dashboardData.put("childrenNames", childrenNames);
        dashboardData.put("Plan", plan);
        dashboardData.put("claimCount", parentClaimCount);
        dashboardData.put("transactionCount", txnCount);

        return dashboardData;
    }
}

//List<Policy> policies = childrens.stream()
//.flatMap(child -> child.getPolicies().stream())
//.collect(Collectors.toList());