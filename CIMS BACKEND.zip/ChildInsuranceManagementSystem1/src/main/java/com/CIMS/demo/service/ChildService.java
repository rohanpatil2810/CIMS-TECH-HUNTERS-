package com.CIMS.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CIMS.demo.entity.Child;
import com.CIMS.demo.entity.Parent;
import com.CIMS.demo.exception.ResourceNotFoundException;
import com.CIMS.demo.repo.ChildRepo;
import com.CIMS.demo.repo.ParentRepo;

@Service
public class ChildService {

    @Autowired
    private ParentRepo parentRepo;

    @Autowired
    private ChildRepo childRepo;

    public Child addChildWithParentEmail(String parentEmailId, Child child) {
        Parent parent = parentRepo.findByParentEmailId(parentEmailId);
        if (parent == null) {
            throw new ResourceNotFoundException("Parent with email " + parentEmailId + " not found.");
        }
        child.setParent(parent);
        return childRepo.save(child);
    }

    public List<Child> getAllChildData() {
        return childRepo.findAll();
    }
}
