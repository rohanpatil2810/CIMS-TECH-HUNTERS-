package com.CIMS.demo.repo;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CIMS.demo.entity.Child;
import com.CIMS.demo.entity.Parent;
import com.CIMS.demo.entity.Plan;
import com.CIMS.demo.entity.Policy;

public interface PolicyRepo extends JpaRepository<Policy, Long> {

	List<Policy> findByEndDateBefore(LocalDate endDate);
	
	
	// Get all policies whose endDate is after today (i.e., still active)
	List<Policy> findByEndDateAfter(LocalDate currentDate);

	List<Policy> findByPlan(Plan plan);

	// Custom query to find policy by parent, child, and plan
    List<Policy> findByParentAndChildAndPlan(Parent parent, Child child, Plan plan);

	

}
