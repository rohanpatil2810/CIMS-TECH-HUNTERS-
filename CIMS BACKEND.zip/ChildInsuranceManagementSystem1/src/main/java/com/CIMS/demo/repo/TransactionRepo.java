package com.CIMS.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CIMS.demo.entity.Transaction;

public interface TransactionRepo extends JpaRepository<Transaction, Integer>{

}
