package com.CIMS.demo.exception;

public class EmailUpdateFailedException extends RuntimeException {
    public EmailUpdateFailedException(String message) {
        super(message);
    }
}
