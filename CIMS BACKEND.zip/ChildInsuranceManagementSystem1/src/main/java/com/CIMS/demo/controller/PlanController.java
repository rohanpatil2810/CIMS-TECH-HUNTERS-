package com.CIMS.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.CIMS.demo.entity.Plan;
import com.CIMS.demo.service.PlanService;

@RestController
@CrossOrigin("*")
@RequestMapping("api/plan")
public class PlanController {

    @Autowired
    PlanService planservice;

    @PostMapping("/addplan")
    public ResponseEntity<String> addPlanDetails(@RequestBody Plan plan) {
        String result = planservice.addPlanHere(plan);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/delplan")
    public ResponseEntity<String> deletePlan(@RequestBody Plan plan) {
        String result = planservice.deletePlan(plan);
        return ResponseEntity.ok(result);
    }
}
