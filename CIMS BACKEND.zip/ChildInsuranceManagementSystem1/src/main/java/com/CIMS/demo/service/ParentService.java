package com.CIMS.demo.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.CIMS.demo.dto.ParentChildDTO;
import com.CIMS.demo.entity.Parent;
import com.CIMS.demo.exception.EmailUpdateFailedException;
import com.CIMS.demo.exception.InvalidCredentialsException;
import com.CIMS.demo.exception.ResourceNotFoundException;
import com.CIMS.demo.repo.ParentRepo;

@Service
public class ParentService {

    @Autowired
    private ParentRepo parentrepository;

    @Autowired
    private DashboardService dashboardService;

    @Autowired
    private EmailService emailService;
    
    public List<String> getPlanNamesOfParent(String parentEmail) {
        Parent parent = parentrepository.findByParentEmailId(parentEmail);
        if (parent == null) {
            throw new ResourceNotFoundException("Parent not found with email: " + parentEmail);
        }

        List<String> planNames = parent.getChildren().stream()
            .flatMap(child -> child.getPolicies().stream())
            .map(policy -> policy.getPlan().getName()) // Plan -> String
            .distinct()
            .collect(Collectors.toList());

        return planNames;
    }
    
    public ResponseEntity<String> registerParentHere(Parent parent) {
        if (parent == null) {
            throw new ResourceNotFoundException("Parent registration failed. Parent data is missing.");
        }

        if (parentrepository.existsByParentEmailId(parent.getParentEmailId())) {
            throw new EmailUpdateFailedException("Email is already registered. Please use another email.");
        }

        if (parentrepository.existsByContactNumber(parent.getContactNumber())) {
            throw new EmailUpdateFailedException("Contact number already registered. Please use another number.");
        }

        Parent savedParent = parentrepository.save(parent);

        System.out.println("✅ Parent registered successfully: " + savedParent.getParentEmailId());

        // ✅ Now send email in a new thread, but first log it
        new Thread(() -> {
            try {
                System.out.println("📧 Sending registration email to: " + savedParent.getParentEmailId());
                emailService.sendRegistrationEmail(savedParent.getParentEmailId(), savedParent.getParentName());
                System.out.println("✅ Email sent successfully to: " + savedParent.getParentEmailId());
            } catch (Exception e) {
                System.err.println("❌ Email sending failed: " + e.getMessage());
            }
        }).start();

        return ResponseEntity.ok("Parent registration successful.");
    }


 // Method to get parent details along with children names
    public List<ParentChildDTO> getAllParentsWithChildren() {
        List<Parent> parents = parentrepository.findAll();
        List<ParentChildDTO> parentChildDTOList = new ArrayList<>();

        // Iterate over each parent and collect data
        for (Parent parent : parents) {
            ParentChildDTO parentChildDTO = new ParentChildDTO();
            parentChildDTO.setParentName(parent.getParentName());
            parentChildDTO.setParentEmailId(parent.getParentEmailId());
            parentChildDTO.setContactNumber(parent.getContactNumber());

            // Get all child names for this parent
            List<String> childrenNames = parent.getChildren().stream()
                                              .map(child -> child.getChildName())
                                              .collect(Collectors.toList());
            parentChildDTO.setChildrenNames(childrenNames);

            parentChildDTOList.add(parentChildDTO);
        }

        return parentChildDTOList;
    }



    public ResponseEntity<Map<String, Object>> loginAndReturnDashboard(Parent parent) {
        String email = parent.getParentEmailId();
        Parent existing = parentrepository.findByParentEmailId(email);

        if (existing != null && existing.getParentPw().equals(parent.getParentPw())) {
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Login Successful");
            response.put("dashboard", dashboardService.parentDashboard(email));
            return ResponseEntity.ok(response);
        } else {
            throw new InvalidCredentialsException("Invalid Email or Password.");
        }
    }

    public ResponseEntity<String> changePassword(String email, String pw) {
        Parent parent = parentrepository.findByParentEmailId(email);
        if (parent != null) {
            parentrepository.updateParentPw(email, pw);
            return ResponseEntity.ok("Password changed successfully.");
        }
        throw new ResourceNotFoundException("Incorrect Email ID. Password change failed.");
    }

    public ResponseEntity<String> updateParentEmail(String oldEmail, String newEmail) {
        Parent existing = parentrepository.findByParentEmailId(oldEmail);
        if (existing != null && newEmail != null && !newEmail.isBlank()) {
            // Check if new email already taken
            if (parentrepository.existsByParentEmailId(newEmail)) {
                throw new EmailUpdateFailedException("New email already registered. Choose another one.");
            }
            existing.setParentEmailId(newEmail);
            parentrepository.save(existing);
            return ResponseEntity.ok("Email updated to: " + newEmail);
        }
        throw new EmailUpdateFailedException("Email update failed. Please check the email provided.");
    }

    public List<Parent> getAllParentData() {
        return parentrepository.findAll();
    }
}