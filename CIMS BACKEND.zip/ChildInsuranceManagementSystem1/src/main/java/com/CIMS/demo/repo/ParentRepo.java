package com.CIMS.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.CIMS.demo.entity.Parent;

import jakarta.transaction.Transactional;

public interface ParentRepo extends JpaRepository<Parent, Integer> {
	
	boolean existsByParentEmailId(String parentEmailId);

	boolean existsByContactNumber(String contactNumber);

	void deleteByParentEmailId(String parentEmailId);

	public Parent findByParentEmailId(String email);
	
	//findByEmail(String email);
	 Parent findByParentName(String name);
	 
	@Modifying
	@Transactional
	@Query("UPDATE Parent p SET p.parentPw = :password WHERE p.parentEmailId = :email")
	void updateParentPw(@Param("email") String email, @Param("password") String password);

	@Modifying
	@Transactional
	@Query("UPDATE Parent p SET p.parentEmailId = :newEmail WHERE p.parentEmailId = :oldEmail")
	void updateParentEmail(@Param("oldEmail") String oldEmail, @Param("newEmail") String newEmail);



}
