package com.CIMS.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.CIMS.demo.entity.Claim;

public interface ClaimRepo  extends JpaRepository<Claim , Integer>{

	@Query("SELECT CASE WHEN COUNT(c) > 0 THEN true ELSE false END " +
	           "FROM Claim c WHERE c.policy.id = :policyId AND c.status = :status")
	    boolean existsByPolicyIdAndStatus(@Param("policyId") Long policyId, 
	                                    @Param("status") String status);
	
	// Add this method to find claims by status
    List<Claim> findByStatus(String status);
	
}
