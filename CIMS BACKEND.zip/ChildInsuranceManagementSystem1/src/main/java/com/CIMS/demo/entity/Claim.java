package com.CIMS.demo.entity;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Claim {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int claimId;
	private String reason;
	private LocalDate date;
	private String status;
	
	
	@ManyToOne
	@JsonBackReference("parent-claim")
	@JoinColumn(name = "parent_id")
	private Parent parent;
	
	@ManyToOne
	@JsonBackReference("policy-claim")
	@JoinColumn(name = "policy_id")
	private Policy policy;
	
	
	public Claim(){}

	public Claim(int claimId, String reason, LocalDate date, String status, Parent parent, Policy policy) {
		super();
		this.claimId = claimId;
		this.reason = reason;
		this.date = date;
		this.status = status;
		this.parent = parent;
		this.policy = policy;
	}

	public int getClaimId() {
		return claimId;
	}

	public void setClaimId(int claimId) {
		this.claimId = claimId;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public Policy getPolicy() {
		return policy;
	}

	public void setPolicy(Policy policy) {
		this.policy = policy;
	}

	@Override
	public String toString() {
		return "Claim [claimId=" + claimId + ", reason=" + reason + ", date=" + date + ", status=" + status
				+ ", parent=" + parent + ", policy=" + policy + "]";
	}

}
