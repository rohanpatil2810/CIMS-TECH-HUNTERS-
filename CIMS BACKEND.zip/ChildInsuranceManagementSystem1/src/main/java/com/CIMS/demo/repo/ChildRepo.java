package com.CIMS.demo.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CIMS.demo.entity.Child;
import com.CIMS.demo.entity.Parent;

public interface ChildRepo extends JpaRepository<Child, Integer>{

	List<Child> findByChildName(String childName);
	
	Optional<Child> findByChildNameAndParent(String childName, Parent parent);

	
//	@Modifying
//	@Transactional
//	@Query("UPDATE Child c SET c.parent_parent_id = :id")
//	void updateParentID(@Param("id") int id);
}
