package com.CIMS.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.CIMS.demo.exception.EmailSendFailedException;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender javaMailSender;

    private final String senderEmail = "sundaramchildinsurance@gmail.com"; // ✅ Set once here

    public void sendRegistrationEmail(String toEmail, String parentName) {
        int attempts = 0;
        boolean success = false;

        while (attempts < 3 && !success) {
            try {
                SimpleMailMessage message = new SimpleMailMessage();
                message.setFrom(senderEmail); // ✅ Always consistent sender
                message.setTo(toEmail);
                message.setSubject("Registration Successful - Child Insurance Management System");
                message.setText(
                    "Dear " + parentName + ",\n\n" +
                    "Thank you for registering with the Child Insurance Management System (CIMS).\n\n" +
                    "If you have any questions, feel free to reply to this email.\n\n" +
                    "Best Regards,\n" +
                    "CIMS Team"
                );

                javaMailSender.send(message);
                success = true; // ✅ Email sent successfully
            } catch (MailException e) {
                attempts++;
                System.err.println("Attempt " + attempts + " failed to send email: " + e.getMessage());
                if (attempts >= 3) {
                    throw new EmailSendFailedException("Failed to send registration email after multiple attempts.", e);
                }
                try {
                    Thread.sleep(2000); // wait 2 seconds before retry
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }
    public void sendClaimStatusEmail(String to, String parentName, String claimStatus) {
        String subject = "Insurance Claim Status: " + claimStatus;
        String body = "Dear " + parentName + ",\n\n"
            + "We are writing to inform you that your insurance claim has been " + claimStatus.toLowerCase() + ".\n"
            + "Please visit your nearest branch with any required documents for further assistance.\n\n"
            + "Thank you for choosing C- Insurance.\n\n"
            + "Warm regards,\n"
            + "C- Insurance Team";

        sendEmail(to, subject, body); // assumes you already have this method to send emails
    }
    
    private void sendEmail(String toEmail, String subject, String body) {
        int attempts = 0;
        boolean success = false;

        while (attempts < 3 && !success) {
            try {
                SimpleMailMessage message = new SimpleMailMessage();
                message.setFrom(senderEmail);
                message.setTo(toEmail);
                message.setSubject(subject);
                message.setText(body);

                javaMailSender.send(message);
                success = true;
            } catch (MailException e) {
                attempts++;
                System.err.println("Attempt " + attempts + " failed to send email: " + e.getMessage());
                if (attempts >= 3) {
                    throw new EmailSendFailedException("Failed to send email after multiple attempts.", e);
                }
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }



}





//package com.CIMS.demo.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.mail.MailException;
//import org.springframework.mail.SimpleMailMessage;
//import org.springframework.mail.javamail.JavaMailSender;
//import org.springframework.stereotype.Service;
//
//import com.CIMS.demo.exception.EmailSendFailedException;
//
//@Service
//public class EmailService {
//
//    @Autowired
//    private JavaMailSender javaMailSender;
//
//    private final String senderEmail = "sundaramchildinsurance@gmail.com"; // ✅ Set once here
//
//    public void sendRegistrationEmail(String toEmail, String parentName) {
//        int attempts = 0;
//        boolean success = false;
//
//        while (attempts < 3 && !success) {
//            try {
//                SimpleMailMessage message = new SimpleMailMessage();
//                message.setFrom(senderEmail); // ✅ Always consistent sender
//                message.setTo(toEmail);
//                message.setSubject("Registration Successful - Child Insurance Management System");
//                message.setText(
//                    "Dear " + parentName + ",\n\n" +
//                    "Thank you for registering with the Child Insurance Management System (CIMS).\n\n" +
//                    "If you have any questions, feel free to reply to this email.\n\n" +
//                    "Best Regards,\n" +
//                    "CIMS Team"
//                );
//
//                javaMailSender.send(message);
//                success = true; // ✅ Email sent successfully
//            } catch (MailException e) {
//                attempts++;
//                System.err.println("Attempt " + attempts + " failed to send email: " + e.getMessage());
//                if (attempts >= 3) {
//                    throw new EmailSendFailedException("Failed to send registration email after multiple attempts.", e);
//                }
//                try {
//                    Thread.sleep(2000); // wait 2 seconds before retry
//                } catch (InterruptedException ie) {
//                    Thread.currentThread().interrupt();
//                }
//            }
//        }
//    }
//}
//
//
