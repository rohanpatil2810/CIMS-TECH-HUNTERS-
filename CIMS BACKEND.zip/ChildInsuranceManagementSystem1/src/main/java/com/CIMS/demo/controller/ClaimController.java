package com.CIMS.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.CIMS.demo.entity.Claim;
import com.CIMS.demo.service.ClaimService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/claims")
public class ClaimController {

    @Autowired
    private ClaimService claimService;

    @PostMapping("/submit")
    public ResponseEntity<String> submitClaim(@RequestBody Claim claim) {
        return claimService.claimHere(claim);
    }
    
    @GetMapping("/pending")
    public ResponseEntity<List<Claim>> getAllPendingClaims() {
        return claimService.getAllPendingClaims();
    }

    @PutMapping("/approve/{claimId}")
    public ResponseEntity<String> approveClaim(@PathVariable Integer claimId) {
        return claimService.updateClaimStatus(claimId, "Approved");
    }

    @PutMapping("/reject/{claimId}")
    public ResponseEntity<String> rejectClaim(@PathVariable Integer claimId) {
        return claimService.updateClaimStatus(claimId, "Rejected");
    }

    
}