package com.CIMS.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.CIMS.demo.entity.Child;
import com.CIMS.demo.service.ChildService;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/child")
public class ChildController {

    @Autowired
    private ChildService childService;

    @PostMapping("/add")
    public ResponseEntity<Child> addChild(@RequestParam String parentEmailId, @RequestBody Child child) {
        Child savedChild = childService.addChildWithParentEmail(parentEmailId, child);
        return ResponseEntity.status(201).body(savedChild); // 201 Created
    }
}
