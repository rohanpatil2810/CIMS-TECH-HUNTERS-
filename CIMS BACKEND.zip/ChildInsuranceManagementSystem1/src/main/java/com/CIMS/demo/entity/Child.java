package com.CIMS.demo.entity;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Child {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int childId;
	private String childName;
	private String childGender;
	private int childAge;
	private LocalDate dateOfBirth;
	
//	@ManyToOne
//	@JoinColumn(name = "parent_Id") //write nullable=false
//	private Parent parent;
//	
//	@OneToMany
//	@JoinColumn(name="claimId")
//	private Claim claim;
	
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JsonBackReference("parent-child")
	@JoinColumn(name = "parent_id", nullable = false)
	private Parent parent;
	
	//ROHAN CHANGED HERE MAY5 12:44
//    @ManyToOne
//    @JsonBackReference
//	@JoinColumn(name = "parent_id")
//    private Parent parent;

    @OneToMany(mappedBy = "child")
    @JsonManagedReference("child-policy")
    private List<Policy> policies;
    
    public Child(){}
	public Child(int childId, String childName, String childGender, int childAge, LocalDate dateOfBirth, Parent parent,
			List<Policy> policies) {
		super();
		this.childId = childId;
		this.childName = childName;
		this.childGender = childGender;
		this.childAge = childAge;
		this.dateOfBirth = dateOfBirth;
		this.parent = parent;
		this.policies = policies;
	}

	public int getChildId() {
		return childId;
	}

	public void setChildId(int childId) {
		this.childId = childId;
	}

	public String getChildName() {
		return childName;
	}

	public void setChildName(String childName) {
		this.childName = childName;
	}

	public String getChildGender() {
		return childGender;
	}

	public void setChildGender(String childGender) {
		this.childGender = childGender;
	}

	public int getChildAge() {
		return childAge;
	}

	public void setChildAge(int childAge) {
		this.childAge = childAge;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public List<Policy> getPolicies() {
		return policies;
	}

	public void setPolicies(List<Policy> policies) {
		this.policies = policies;
	}

	@Override
	public String toString() {
		return "Child [childId=" + childId + ", childName=" + childName + ", childGender=" + childGender + ", childAge="
				+ childAge + ", dateOfBirth=" + dateOfBirth + ", parent=" + parent + ", policies=" + policies + "]";
	}
    
    
	
	
	
}
