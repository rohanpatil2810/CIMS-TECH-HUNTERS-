package com.CIMS.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChildInsuranceManagementSystem1Application {

	public static void main(String[] args) {
		SpringApplication.run(ChildInsuranceManagementSystem1Application.class, args);
	}

}
