package com.CIMS.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.CIMS.demo.entity.Admin;
import com.CIMS.demo.entity.Child;
import com.CIMS.demo.entity.Parent;
import com.CIMS.demo.entity.Plan;
import com.CIMS.demo.service.AdminService;
import com.CIMS.demo.service.ChildService;
import com.CIMS.demo.service.ParentService;
import com.CIMS.demo.service.PlanService;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private AdminService adminservice;

    @Autowired
    private PlanService planservice;

    @Autowired
    private ParentService parentservice;

    @Autowired
    private ChildService childservice;

    @PostMapping("/login")
    public ResponseEntity<String> adminLogin(@RequestBody Admin admin) {
        return adminservice.adminLoginHere(admin);
    }

    @PostMapping("/addplan")
    public ResponseEntity<String> addNewPlanAdmin(@RequestBody Plan plan) {
        String message = planservice.addPlanHere(plan);
        return ResponseEntity.ok(message);
    }

    @GetMapping("/getallplan")
    public ResponseEntity<List<Plan>> getAllPlan() {
        List<Plan> plans = planservice.getAllPlanData();
        return ResponseEntity.ok(plans);
    }

    @PostMapping("/delplan")
    public ResponseEntity<String> deletePlan(@RequestBody Plan plan) {
        String message = planservice.deletePlan(plan);
        return ResponseEntity.ok(message);
    }

    @GetMapping("/getAllParent")
    public ResponseEntity<List<Parent>> getAllParent() {
        List<Parent> parents = parentservice.getAllParentData();
        return ResponseEntity.ok(parents);
    }

    @GetMapping("/getAllChild")
    public ResponseEntity<List<Child>> getAllChild() {
        List<Child> children = childservice.getAllChildData();
        return ResponseEntity.ok(children);
    }
}
